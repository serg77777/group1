package lesson140410;

public interface NewsMaker {

	String getNews();

}
