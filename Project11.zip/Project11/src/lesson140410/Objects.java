package lesson140410;

public class Objects {

	public static void main(String[] args) {
		
		Object o = new Object();
		
	}
	
}
