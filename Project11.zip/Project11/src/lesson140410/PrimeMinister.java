package lesson140410;

public class PrimeMinister implements NewsMaker{

	@Override
	public String getNews() {
		return "без комментариев";
	}

}
