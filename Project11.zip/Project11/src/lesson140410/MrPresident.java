package lesson140410;

public class MrPresident implements NewsMaker{

	@Override
	public String getNews() {
		return "верной дорогой идете, товарищи";
	}

}
