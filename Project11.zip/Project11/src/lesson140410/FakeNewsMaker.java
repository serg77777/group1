package lesson140410;

public class FakeNewsMaker {

	public String getNews() {
		return "ыыыыыыыыыыыы";
	}
	
}
