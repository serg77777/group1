package lesson140410;

public class Urgant implements NewsMaker{

	@Override
	public String getNews() {
		return "хахахаха";
	}

}
