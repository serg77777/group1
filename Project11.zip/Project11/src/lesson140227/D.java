package lesson140227;

public class D {


	public void doIt() {
		
		string name;
		
		D(string name) {
			this.name = name;
		}
		
		
		System.out.println(name + " did it!!!");
		
	}


}
