package lesson140227;

public class G {
	
	H h;
	int index = 10;
	
	void doIt() {
		h.doIt(this);
	}

	public int getIndex() {
		return index;
	}
	
	
}
