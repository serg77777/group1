package lesson140227;

public class H {
	
	int index = 30;

	public void doIt(G g) {
		
		int i = g.getIndex();
		System.out.println(index + i);
		
	}

}
