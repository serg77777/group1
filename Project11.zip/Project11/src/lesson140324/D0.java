package lesson140324;

public class D0 {
	
	public void d(){
		System.out.println("level 0");
	
	}

	public void d0(){
		d();
	}
}
