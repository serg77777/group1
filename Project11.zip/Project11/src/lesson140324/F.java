package lesson140324;

public class F extends E{

	private int state=20;

}
