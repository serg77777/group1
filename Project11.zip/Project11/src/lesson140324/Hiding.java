package lesson140324;

public class Hiding {

	public static void main(String[] args) {
		F f = new F();
		System.out.println(f.getState());
		f.printState();
	}
}
