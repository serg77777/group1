package lesson140324;

public class D1 extends D0{
	
	@Override
	public void d(){
		System.out.println("level 1");
		super.d();
	}
	public void d1(){
		super.d();
	}

}
