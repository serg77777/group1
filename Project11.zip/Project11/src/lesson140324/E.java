package lesson140324;

public class E {

	 int state=10;
	public void printState(){
		System.out.println(state);
	}
}
