package lesson140415.invoke;

public class SimpleRobot implements Robot{

	@Override
	public void up() {
		System.out.println("up");
		
	}

	@Override
	public void down() {
		System.out.println("down");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void left() {
		System.out.println("left");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void right() {
		System.out.println("right");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void stop() {
		System.out.println("stop");
		// TODO Auto-generated method stub
		
	}

	
	
	
	
}
