package lesson140415.invoke;

public class RobotControlPanel {

	public static void main(String[] args) {
		
		SimpleRobot robot = new SimpleRobot();
		
		startKeyboardInterface();
		
		
	}

	private static void startKeyboardInterface() {
		new Thread()
	}
	
	
	
}
