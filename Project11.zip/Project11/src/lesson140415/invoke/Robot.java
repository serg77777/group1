package lesson140415.invoke;

public interface Robot {

	void up();
	void down();
	void left();
	void right();
	void stop();
	
}
