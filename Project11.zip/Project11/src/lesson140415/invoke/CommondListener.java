package lesson140415.invoke;

public interface CommondListener {
			void command(String command);
}
