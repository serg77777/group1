package lesson140415.invoke;

public class Q {

	Q(){
		
		
	}
	Q(int a)
	{
		this();
	}
	
	public int a = 10;
	

}

public class Wqwe extends Q {
	
}

