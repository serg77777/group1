package lesson140305inheritance;

public class C {
	protected int state = 10;

	protected void changeState() {
		state *= 2;
	}
}
