package lesson140305inheritance;

public abstract class AnimalPlanet {
	abstract public void makeSound();
	abstract public void feed(String food);
	abstract protected void go();
	
}
