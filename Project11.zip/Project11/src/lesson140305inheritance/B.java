package lesson140305inheritance;

public class B extends A {

	public void doubleState() {
		setState(getState() * 2);
	}
}
