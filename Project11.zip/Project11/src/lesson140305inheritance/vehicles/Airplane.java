package lesson140305inheritance.vehicles;

public class Airplane extends Vehicle {

}
