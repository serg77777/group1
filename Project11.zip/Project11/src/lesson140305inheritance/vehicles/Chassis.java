package lesson140305inheritance.vehicles;

public class Chassis {

}
