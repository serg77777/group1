package lesson140305inheritance.vehicles;

public class Wheel {
	public void makesound() {
		System.out.println("wheel ;  ;) (;shshshshshshshshhshsh");
	}
}
