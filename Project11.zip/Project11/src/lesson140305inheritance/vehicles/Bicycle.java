package lesson140305inheritance.vehicles;


public class Bicycle extends Vehicle {

}
