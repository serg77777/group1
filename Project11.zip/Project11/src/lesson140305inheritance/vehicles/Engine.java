package lesson140305inheritance.vehicles;

public class Engine {
public void start(){
	
}
public void stop(){}

}
