package lesson140305inheritance.vehicles;

public class Vehicle {

	public void moveTo(int x, int y) {
		
	}
	
}
