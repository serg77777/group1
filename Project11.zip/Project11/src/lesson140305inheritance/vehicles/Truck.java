package lesson140305inheritance.vehicles;

public class Truck extends Car {

	public Truck(Engine engine,
			lesson140305inheritance.vehicles.Wheel[] wheels, Chassis chassis) {
		super(engine, wheels, chassis);
		// TODO Auto-generated constructor stub
	}

}
