package lesson140305inheritance;

public class Cat extends HomeAnimalPlanet {

	@Override
	public void brush() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void makeSound() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void feed(String food) {
		// TODO Auto-generated method stub
		
	}

}
