package lesson140305inheritance;

public class A {

	 private int _state;

	public int getState() {
		return _state;
	}

	public void setState(int state) {
		this._state = state;
	}
	 
	 
	 
}
