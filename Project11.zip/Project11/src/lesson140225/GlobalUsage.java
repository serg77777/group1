package lesson140225;

public class GlobalUsage {
	public static void main(String[] args) {
		System.out.println(Scope.x);
	}
}
