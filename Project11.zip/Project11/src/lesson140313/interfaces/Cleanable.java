package lesson140313.interfaces;

public interface Cleanable {

	public abstract void clean();
	
}
