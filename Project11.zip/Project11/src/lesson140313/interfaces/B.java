package lesson140313.interfaces;

public class B extends A {
	
	

}
