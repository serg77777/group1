package lesson140313.interfaces;

public class Table extends Furniture {

	@Override
	public void clean() {
		System.out.println("cleaned table");

	}

}
