package lesson140313.interfaces;

public class Violin extends StringInstruments {

	@Override
	public void play() {
		// TODO Auto-generated method stub

	}

	@Override
	public void crash() {
		// TODO Auto-generated method stub

	}
	
	public void piccicato(){
		System.out.println("piccicato");
	}

}
