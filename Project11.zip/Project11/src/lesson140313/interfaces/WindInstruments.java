package lesson140313.interfaces;

public abstract class WindInstruments extends MusicInstrument{

		


}
