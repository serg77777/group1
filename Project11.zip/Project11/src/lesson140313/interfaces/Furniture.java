package lesson140313.interfaces;

public abstract class Furniture implements Cleanable{

}
