package lesson140313.interfaces;

public interface SimpleList extends Iterable {


	void add (Object data);
	
}
