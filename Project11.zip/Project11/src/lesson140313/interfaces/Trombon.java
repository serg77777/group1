package lesson140313.interfaces;

public class Trombon extends WindInstruments{

	@Override
	public void play() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void crash() {
		// TODO Auto-generated method stub
		
	}

}
