package lesson140313.interfaces;

public class A {
	
	int state;
	
	public void changeState() {
		this.state *= 2;
	}

}
