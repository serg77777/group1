package lesson140409.jvm;

public class NewsMaker {

	public String getFreshNews() {
		// TODO Auto-generated method stub
		return null;
	}
}
