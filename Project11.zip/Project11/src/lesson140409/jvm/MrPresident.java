package lesson140409.jvm;

public class MrPresident {

	public String getFreshNews() {
		return "Bla-bla";
	}
}
