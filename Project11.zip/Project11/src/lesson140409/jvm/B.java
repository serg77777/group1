package lesson140409.jvm;

public class B {

}
