package lesson140312.interfaces;

public interface SimpleList {

	void add(String element);
	Node first();
}
