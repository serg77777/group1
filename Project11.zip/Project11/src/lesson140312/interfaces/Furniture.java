package lesson140312.interfaces;

public abstract class Furniture implements Cleanable{

}
