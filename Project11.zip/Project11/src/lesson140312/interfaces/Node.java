package lesson140312.interfaces;

public class Node {

	
	public Node(Object data, Node next) {
		super();
		this.data = data;
		this.next = next;
	}
	
	Object data;
	Node next;
}
