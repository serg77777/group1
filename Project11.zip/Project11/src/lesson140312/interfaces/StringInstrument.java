package lesson140312.interfaces;

public abstract class StringInstrument extends MusicInstrument {

}
