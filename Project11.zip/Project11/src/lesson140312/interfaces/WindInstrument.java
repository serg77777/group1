package lesson140312.interfaces;

public abstract class WindInstrument extends MusicInstrument {

}
