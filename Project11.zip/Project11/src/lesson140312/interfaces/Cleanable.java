package lesson140312.interfaces;

public interface Cleanable {

	void clean();
}
