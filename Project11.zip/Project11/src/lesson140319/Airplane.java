package lesson140319;

public class Airplane implements AirVehicle {
	
	@Override
	public void fly() {
		System.out.println("flying");
	}

}
