package lesson140319;

public class Boat implements SeaVehicle {
	
	@Override
	public void sail() {
		System.out.println("sail");
	}
}
