package lesson140319;

public interface AmphibiaVehicle extends LandVehicle, SeaVehicle {

}
