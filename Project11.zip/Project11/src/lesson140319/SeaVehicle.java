package lesson140319;

public interface SeaVehicle {

	public void sail();

}