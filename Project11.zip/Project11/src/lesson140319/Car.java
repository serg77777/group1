package lesson140319;

public class Car implements LandVehicle {
	
	@Override
	public void drive() {
		System.out.println("drive");
	}

}
