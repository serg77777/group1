package lesson140319;

public interface LandVehicle {

	public abstract void drive();

}