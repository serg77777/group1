package lesson140319;

public interface AirVehicle {
	
	void fly();

}
