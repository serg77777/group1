package lesson140319;

public class B {
	
	final int state;
	
	public B(int initialState) {
		state = 10;
	}

}
