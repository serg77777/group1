package lesson140429.annotations;

public @interface Single {
	
	int value();	

}
