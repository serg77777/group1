package lesson140327.inner;

public interface TemperatureObserver {

	void cirrentTemp(int temp);
	
}
