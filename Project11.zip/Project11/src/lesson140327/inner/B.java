package lesson140327.inner;

public class B {

	
	
	int state;
	
}
