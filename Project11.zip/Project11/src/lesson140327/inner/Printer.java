package lesson140327.inner;

public interface Printer {

	void printState();
	
}
