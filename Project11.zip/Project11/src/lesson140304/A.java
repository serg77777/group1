package lesson140304;

public class A {

	public A() {

	}

	B b = new B();

	public void doIt() {
		b.doIt();

	}

}
