package lesson140304;

public class C {

	private int _state = 10;

	public int getState() {
		return _state;
	}

	public void setState(int state) {
		_state = state;
	}

	
}
