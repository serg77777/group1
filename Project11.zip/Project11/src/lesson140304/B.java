package lesson140304;

class B {

	C c = new C();
	
	public void doIt() {
		System.out.println("I did it! c state is " + c.getState());
	}

}
