package lesson140325;

public class H extends G{

	int stateH = 20;
	
	public void changeState() {
		state = getState() / 2;
	}
	
}
