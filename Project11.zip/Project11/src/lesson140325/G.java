package lesson140325;

public class G {

	public int state = 10;
	
	public int getState() {
		return state;
	}
	
}
