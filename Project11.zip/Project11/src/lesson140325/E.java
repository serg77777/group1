package lesson140325;

public class E implements Changable{

	@Override
	public void changeState() {
		
		System.out.println("e");
	
	}
	
}
