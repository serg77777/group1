package lesson140325;

public interface Changable {
	void changeState();

}
