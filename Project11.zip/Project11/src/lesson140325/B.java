package lesson140325;

public class B extends A{

	{
		state = 20;
	}
	@Override
	public void changeState() {
		state *=10;
	}
	
}
