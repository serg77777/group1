package lesson140325;

public class D implements Changable{

	@Override
	public void changeState() {
		
		System.out.println("d");
		
	}
	
}
