package lesson140403.exceptions;

public class StackOverflow extends Exception {

}
