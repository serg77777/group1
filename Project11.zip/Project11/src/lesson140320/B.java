package lesson140320;

public class B extends A {

	B(int initialState) {
		super(initialState);
	}
	

}
