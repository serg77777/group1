package lesson140320;

public class Airplane implements AirTransport {

	@Override
	public void fly(){
		System.out.println("fly");
	}
	
}
