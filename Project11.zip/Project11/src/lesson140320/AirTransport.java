package lesson140320;

public interface AirTransport {

	public abstract void fly();

}