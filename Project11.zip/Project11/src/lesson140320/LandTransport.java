package lesson140320;

public interface LandTransport {
	void drive();

}
