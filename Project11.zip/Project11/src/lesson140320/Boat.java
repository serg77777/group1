package lesson140320;

public class Boat implements SeaTransport {

	@Override
	public void sail() {
		System.out.println("sail");
	}

}
