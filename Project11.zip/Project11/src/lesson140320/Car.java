package lesson140320;

public class Car implements LandTransport{

	@Override
	public void drive() {
		
		System.out.println("drive");
		
	}
	
}
