package lesson140320;

public interface SeaAirTransport extends SeaTransport, AirTransport{

}
