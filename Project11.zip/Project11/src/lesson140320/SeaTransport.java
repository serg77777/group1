package lesson140320;

public interface SeaTransport {

	public abstract void sail();

}