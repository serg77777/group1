package lesson140320;

public class IndianCar extends Car {

	@Override
	public void drive() {
		System.out.println("I am a disco danser....");
	}

}
