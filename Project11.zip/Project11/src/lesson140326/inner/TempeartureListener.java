package lesson140326.inner;

public interface TempeartureListener {

	public abstract void changed(int temp);

}