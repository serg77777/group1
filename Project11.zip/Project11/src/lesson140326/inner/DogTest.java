package lesson140326.inner;

public class DogTest {

	public static void main(String[] args) {
		
		DogBrain brain = new DogBrain();
		
		brain.pat();
		brain.feed();
		brain.feed();
		brain.pat();
		brain.pat();
		brain.pat();
		
	}
	
}
