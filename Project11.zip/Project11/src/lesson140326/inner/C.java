package lesson140326.inner;

public class C {
	
	int state = 40;
	
	public void printMyState() {
		
	}

}
