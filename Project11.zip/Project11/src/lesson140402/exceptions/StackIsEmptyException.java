package lesson140402.exceptions;

public class StackIsEmptyException extends Exception {

}
