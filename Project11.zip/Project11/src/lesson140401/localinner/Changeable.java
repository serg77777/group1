package lesson140401.localinner;

public interface Changeable {

	public abstract void changeState();

	public abstract Object getState();

}