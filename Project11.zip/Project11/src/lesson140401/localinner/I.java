package lesson140401.localinner;

public interface I {

	void doIt();
	
}
