package lesson140401.localinner;

public interface X {
	I getI();

}
