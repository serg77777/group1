package lesson140331;

public interface SimpleList extends Iterable {


	void add (String element);
	
}
