package lesson140414.reflection;

public interface Robot {
	
	void forward();
	void back();
	void stop();
	void left();
	void right();
	
	
}
